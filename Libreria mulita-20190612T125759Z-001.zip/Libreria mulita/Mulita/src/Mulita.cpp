/*
  Librería para controlar al robot Mulita.
  Desarrollada por Guillermo M. Cortez Riffel para el proyecto de investigacion Robot Mulita de la Universidad Adventista del Plata, Entre Rios, Argentina.
  
  Equipo de investigacion:
  Octavio J. da Silva Gillig
  Guillermo M. Cortez Riffel
  Leandro Bazan
  Sebastian J. Calderon
  Julian U. da Silva Gillig
  Analia Girardi Barreau

  Este codigo es de dominio publico y modificado por ultima vez el 6 de septiembre de 2018.


*/

#include "Arduino.h"
#include "Mulita.h"

Mulita::Mulita()
{
	pinMode(_a,OUTPUT);
	pinMode(_b,OUTPUT);
	pinMode(_c,OUTPUT);
	pinMode(_d,OUTPUT);
	pinMode(_e,OUTPUT);
	pinMode(_f,OUTPUT);
	pinMode(_g,OUTPUT);
	pinMode(_h,OUTPUT);
  pinMode(_pinecho,INPUT);
  pinMode(_pintrigger,OUTPUT);
  _vuelta = 18.0;
}

void Mulita::girarMotor(int uno, int dos, int tres, int cuatro, int i)         //Los motores giran en sentido horario
{
  digitalWrite(uno, _pasos[i][0]);
  digitalWrite(dos, _pasos[i][1]);
  digitalWrite(tres, _pasos[i][2]);
  digitalWrite(cuatro, _pasos[i][3]);
}

void Mulita::atras(double distancia)
{

  for (int j = 0; j < ((distancia / _vuelta) * 512); j++) {
    for (int i = 0; i < 4; i++) {
      girarMotor(_h, _g, _f, _e, i);
      girarMotor(_a, _b, _c, _d, i);
      delayMicroseconds(_retardo);

    }
  }
  apagar();
}

void Mulita::adelante(double distancia) 
{
  for (int j = 0; j < ((distancia / _vuelta) * 512); j++) {
    for (int i = 0; i < 4; i++) {
      girarMotor(_e, _f, _g, _h, i);
      girarMotor(_d, _c, _b, _a, i);
      delayMicroseconds(_retardo);

    }
  }
  apagar();
}

void Mulita::izquierda()                                                    // La mulita realiza giro hacia la izquierda-- 265 pasos = 90°
{
  for (int j = 0; j < 265; j++) {
    for (int i = 0; i < 4; i++) {
      girarMotor(_e, _f, _g, _h, i);
      girarMotor(_a, _b, _c, _d, i);
      delayMicroseconds(_retardo);

    }
  }
  apagar();
}

void Mulita::derecha()                                                      // La mulita realiza giro hacia la izquierda
{

  for (int j = 0; j < 265; j++) {
    for (int i = 0; i < 4; i++) {
      girarMotor(_h, _g, _f, _e, i);
      girarMotor(_d, _c, _b, _a, i);
      delayMicroseconds(_retardo);

    }
  }
  apagar();
}

void  Mulita::izquierda(int grados)                                                    // La mulita realiza giro hacia la izquierda
{
  for (int j = 0; j < 2.98 *grados ; j++) {
    for (int i = 0; i < 4; i++) {
      girarMotor(_e, _f, _g, _h, i);
      girarMotor(_a, _b, _c, _d, i);
      delayMicroseconds(_retardo);

    }
  }
}

void Mulita::derecha(int grados)                                                      // La mulita realiza giro hacia la izquierda
{
  for (int j = 0; j < 2.98*grados ; j++) {
    for (int i = 0; i < 4; i++) {
      girarMotor(_h, _g, _f, _e, i);
      girarMotor(_d, _c, _b, _a, i);
      delayMicroseconds(_retardo);

    }
  }
}

int Mulita::medirDistancia()
{
  digitalWrite(_pintrigger,LOW);
  delayMicroseconds(2);
  digitalWrite(_pintrigger,HIGH);
  delayMicroseconds(10);
  digitalWrite(_pintrigger,LOW);
  _tiempo = pulseIn(_pinecho,HIGH);
  _distanciaCalculada = _tiempo / 58;
  return _distanciaCalculada;
}

void Mulita::apagar()
{
  digitalWrite(_a, LOW);
  digitalWrite(_b, LOW);
  digitalWrite(_c, LOW);
  digitalWrite(_d, LOW);
  digitalWrite(_e, LOW);
  digitalWrite(_f, LOW);
  digitalWrite(_g, LOW);
  digitalWrite(_h, LOW);
}