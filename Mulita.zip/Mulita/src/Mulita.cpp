/*
  Librería para controlar al robot Mulita.
  Desarrollada por Guillermo M. Cortez Riffel para el proyecto de investigacion Robot Mulita de la Universidad Adventista del Plata, Entre Rios, Argentina.
  
  Equipo de investigacion y desarrollo:
  Octavio J. da Silva Gillig
  Guillermo M. Cortez Riffel
  Leandro Bazan
  Sebastian J. Calderon
  Julian U. da Silva Gillig
  Analia Girardi Barreau
  Mayco S. Chavez
  Rocio Learreta

  Este codigo es de dominio publico
  
  Modificado por ultima vez: 13 de abril de 2023.


*/

#include "Arduino.h"
#include "Mulita.h"

int _pasos[8][4] = {
  {1, 0, 0, 0},
  {1, 1, 0, 0},
  {0, 1, 0, 0},
  {0, 1, 1, 0},
  {0, 0, 1, 0},
  {0, 0, 1, 1},
  {0, 0, 0, 1},
  {1, 0, 0, 1}
};

Mulita::Mulita()
{
     _d4 = 11;
	 _d3 = 10;
	 _d2= 9;
	 _d1 = 8;
	 _i4 = 7;
	 _i3 = 6;
	 _i2 = 5;
	 _i1 = 4;
	 _pinecho = 3;
	 _pintrigger = 2;
	 _abajo = 500;
	 _arriba = 700;
   _pasosPorGiro = 4100;
   _servo = 12;

	 _retardo = 1500;
	 _distanciaCalculada;
   _diametroRueda = 0.61; //cm
	 _vuelta = 19.14;  //Circunferencia validada con 3 giros completos de la rueda midiendo un total de 552 mm / 3 giros = 184 mm.192


  pinMode(_d1,OUTPUT);
  pinMode(_d2,OUTPUT);
  pinMode(_d3,OUTPUT);
  pinMode(_d4,OUTPUT);
  pinMode(_i1,OUTPUT);
  pinMode(_i2,OUTPUT);
  pinMode(_i3,OUTPUT);
  pinMode(_i4,OUTPUT);
  pinMode(_pinecho,INPUT);
  pinMode(_pintrigger,OUTPUT);
  pinMode(_servo, OUTPUT);

}
//Permite mover los motores dentro de un ciclo for utilizando una variable, porEj.: int i , pasada por parametros como la variable del loop. Ademas el char para distinguir el tipo de movimiento.
void Mulita::girarMotores(char mov, int i)         //Los motores giran en sentido horario
{
  switch (mov)
  {
  case 'A':                               //Adelante
    digitalWrite(_i1, _pasos[i][3]);
    digitalWrite(_d4, _pasos[i][3]);
    digitalWrite(_i2, _pasos[i][2]);
    digitalWrite(_d3, _pasos[i][2]);
    digitalWrite(_i3, _pasos[i][1]);
    digitalWrite(_d2, _pasos[i][1]);
    digitalWrite(_i4, _pasos[i][0]);
    digitalWrite(_d1, _pasos[i][0]);
    break;
  case 'a':                               //atras
    digitalWrite(_i1, _pasos[i][0]);
    digitalWrite(_d4, _pasos[i][0]);
    digitalWrite(_i2, _pasos[i][1]);
    digitalWrite(_d3, _pasos[i][1]);
    digitalWrite(_i3, _pasos[i][2]);
    digitalWrite(_d2, _pasos[i][2]);
    digitalWrite(_i4, _pasos[i][3]);
    digitalWrite(_d1, _pasos[i][3]);
  break;
  case 'i':                               //Izquierda
    digitalWrite(_i1, _pasos[i][0]);
    digitalWrite(_d1, _pasos[i][0]);
    digitalWrite(_i2, _pasos[i][1]);
    digitalWrite(_d2, _pasos[i][1]);
    digitalWrite(_i3, _pasos[i][2]);
    digitalWrite(_d3, _pasos[i][2]);
    digitalWrite(_i4, _pasos[i][3]);
    digitalWrite(_d4, _pasos[i][3]);
  break;
  case 'd':                               //Derecha
    digitalWrite(_i1, _pasos[i][3]);
    digitalWrite(_d1, _pasos[i][3]);
    digitalWrite(_i2, _pasos[i][2]);
    digitalWrite(_d2, _pasos[i][2]);
    digitalWrite(_i3, _pasos[i][1]);
    digitalWrite(_d3, _pasos[i][1]);
    digitalWrite(_i4, _pasos[i][0]);
    digitalWrite(_d4, _pasos[i][0]);
  break;
  }
  delayMicroseconds(_retardo);

}


void Mulita::adelante(double distancia) 
{
  int i = 0;
  for (double j = 0; j < ((distancia / _vuelta) * _pasosPorGiro); j++) {
    girarMotores('A', i);  
    i++;
    if(i == 8){
      i = 0;
    } 
  }
  apagarMotores();
}

void Mulita::atras(double distancia)
{
  int i = 0;
  for (double j = 0; j < ((distancia / _vuelta) * _pasosPorGiro); j++) {
    girarMotores('a', i);  
    i++;
    if(i == 8){
      i = 0;
    } 
  }
  apagarMotores();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// La mulita realiza un giro completo (no de una rueda si no la combinacion de las dos) con 8940 pasos en modo half step. 1° = 23.6 pasos //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Mulita::izquierda(double grados)                                                    
{
  int i = 0;
  for (double j = 0; j < (grados * 23.2); j++) {
    girarMotores('i', i);  
    i++;
    if(i == 8){
      i = 0;
    } 
  }
  apagarMotores();
}

void Mulita::derecha(double grados)                                                      
{
  int i = 0;
  for (double j = 0; j < (grados * 23.2); j++) {
    girarMotores('d', i);  
    i++;
    if(i == 8){
      i = 0;
    } 
  }
  apagarMotores();
}

void Mulita::apagarMotores()
{
  digitalWrite(_i1, LOW);
  digitalWrite(_i2, LOW);
  digitalWrite(_i3, LOW);
  digitalWrite(_i4, LOW);
  digitalWrite(_d1, LOW);
  digitalWrite(_d2, LOW);
  digitalWrite(_d3, LOW);
  digitalWrite(_d4, LOW);
  
}

void Mulita::subirFibron()
{
  MoverServo(_arriba);
}

void Mulita::bajarFibron()
{
  MoverServo(_abajo);
}

int Mulita::medirDistancia()
{
  digitalWrite(_pintrigger,LOW);
  delayMicroseconds(2);
  digitalWrite(_pintrigger,HIGH);
  delayMicroseconds(10);
  digitalWrite(_pintrigger,LOW);
  _tiempo = pulseIn(_pinecho,HIGH);
  _distanciaCalculada = _tiempo / 58;
  //Es preferible que la distancia sea un poco menor por eso se reduce un 1%.
  _distanciaCalculada = _distanciaCalculada * 0.99;
  return _distanciaCalculada;
}

void Mulita::MoverServo(int pos){
  for(int i = 0; i < 50; i++){
    digitalWrite(_servo, HIGH);
    delayMicroseconds(pos);
    digitalWrite(_servo, LOW);
    delayMicroseconds(20000-pos);
  }
}

void Mulita::fin(){
  delay(3600000);
}