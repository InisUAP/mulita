/*
	Librería para controlar al robot Mulita.
	Desarrollada por Guillermo M. Cortez Riffel para el proyecto de investigacion Robot Mulita de la Universidad Adventista del Plata, Entre Rios, Argentina.
	
	Equipo de investigacion:
	Octavio J. da Silva Gillig
	Guillermo M. Cortez Riffel
	Leandro Bazan
	Sebastian J. Calderon
	Julian U. da Silva Gillig
	Analia Girardi Barreau

	Este codigo es de dominio publico y modificado por ultima vez el 6 de septiembre de 2018.


*/
#ifndef Mulita_h
#define Mulita_h

#include "Arduino.h"

class Mulita
{
  public:
    Mulita();
    void atras(double distancia);
    void adelante(double distancia);
    void izquierda();
    void derecha();
    void izquierda(int grados);
    void derecha(int grados);
    int medirDistancia();

  private:
    const int _a = 11;
	const int _b = 10;
	const int _c = 9;
	const int _d = 8;
	const int _e = 7;
	const int _f = 6;
	const int _g = 5;
	const int _h = 4;
	const int _pinecho = 2;
	const int _pintrigger = 3;

	int _retardo = 1700;
	int _distanciaCalculada;
	double _vuelta;
	int _tiempo;

	int _pasos [4][4] = {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}};

	void girarMotor(int _uno, int _dos, int _tres, int _cuatro, int _i);
	void apagar();
};

#endif